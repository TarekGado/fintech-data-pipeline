import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sqlalchemy import create_engine
from sklearn.linear_model import LinearRegression

print('Tarek')
def extract_clean(filename:str, output_path:str):
    '''
    Extract sales data from csv file and save it to a new csv file
    @param file_path: str, path to the csv file
    @param output_path: str, path to save the new csv file
    '''

    df = pd.read_csv(filename)
    df = impute_missing(df)
    df.to_parquet(output_path)
    
def extract_states(filename:str, output_path:str):
    '''
    Extract sales data from csv file and save it to a new csv file
    @param file_path: str, path to the csv file
    @param output_path: str, path to save the new csv file
    '''

    df = pd.read_csv(filename)
    df = df.rename(columns={
    "code": "State"
    })
    df.to_parquet(output_path)

def combine_sources(filename1:str,filename2:str , output_path:str):
    '''
    Extract sales data from csv file and save it to a new csv file
    @param file_path: str, path to the csv file
    @param output_path: str, path to save the new csv file
    '''
    
    
    fintech_clean = pd.read_parquet(filename1)

    # Load the states dataset
    fintech_states = pd.read_parquet(filename2)

    # Combine the two datasets (assuming both have a 'state' column to join on)
    combined = pd.merge(fintech_clean, fintech_states, on="State", how="left")

    # Save the combined dataset to a new Parquet file
    combined.to_parquet(output_path)

def encoding(filename:str, output_path:str):
    '''
    Extract sales data from csv file and save it to a new csv file
    @param file_path: str, path to the csv file
    @param output_path: str, path to save the new csv file
    '''

    df = pd.read_parquet(filename)
    df = pd.get_dummies(df, columns=['Home_Ownership'])  # Avoid multicollinearity
    encoded_columns = [col for col in df.columns if col.startswith('Home_Ownership')]
    df[encoded_columns] = df[encoded_columns].astype(int)
    df = pd.get_dummies(df, columns=['Verification_Status'])  # Avoid multicollinearity
    encoded_columns = [col for col in df.columns if col.startswith('Verification_Status')]
    df[encoded_columns] = df[encoded_columns].astype(int)
    df = pd.get_dummies(df, columns=['Loan_Status'])  # Avoid multicollinearity
    encoded_columns = [col for col in df.columns if col.startswith('Loan_Status')]
    df[encoded_columns] = df[encoded_columns].astype(int)
    df = pd.get_dummies(df, columns=['Type'])  # Avoid multicollinearity
    encoded_columns = [col for col in df.columns if col.startswith('Type')]
    df[encoded_columns] = df[encoded_columns].astype(int)
    df = pd.get_dummies(df, columns=['Purpose'])  # Avoid multicollinearity
    encoded_columns = [col for col in df.columns if col.startswith('Purpose')]
    df[encoded_columns] = df[encoded_columns].astype(int)
    frequency_encoding = df['Addr_State'].value_counts()
    df['Addr_State_encoded'] = df['Addr_State'].map(frequency_encoding)
    frequency_encoding = df['State'].value_counts()
    df['State_encoded'] = df['State'].map(frequency_encoding)
    df['term_encoded_by_12'] = (df['Term'].str.extract('(\d+)', expand=False).astype(int))/12
    # label_encoder = LabelEncoder()
    # df['letter_grade_encoded'] = label_encoder.fit_transform(df['Letter_Grade'])
    df.to_parquet(output_path)

# def transform_sales_data(filename:str, output_path:str):
#     '''
#     Transform sales data by imputing missing values and encoding categorical columns
#     @param filename: str, path to the csv file
#     @param output_path: str, path to save the new csv file
#     '''

#     df = pd.read_csv(filename)
#     df = impute_missing(df)
#     df = encoding(df)
#     df.to_csv(output_path)

def load_to_db(filename:str, table_name:str, postgres_opt:dict):
    '''
    Load the transformed data to the database
    @param filename: str, path to the csv file
    @param table_name: str, name of the table to create
    @param postgres_opt: dict, dictionary containing postgres connection options (user, password, host,port, db)
    '''
    user, password, host, port, db = postgres_opt.values()
    engine = create_engine(f'postgresql://{user}:{password}@{host}:{port}/{db}')
    df = pd.read_parquet(filename)
    # Set the index to invoice_id
    df.set_index('Customer_Id', inplace=True)
    df.to_sql(table_name, con=engine, if_exists='replace', index=True, index_label='Customer_Id')

# ---- Helper Functions ----

def impute_with_regression(df, target_column, predictor_column):
    """
    Impute missing values in the target column using linear regression with the predictor column.

    Parameters:
    df (pd.DataFrame): DataFrame containing the data
    target_column (str): Name of the column with missing values to impute
    predictor_column (str): Name of the column to use as a predictor

    Returns:
    pd.DataFrame: DataFrame with the target column's missing values imputed
    """
    # Separate data into rows with and without missing target_column
    df_missing = df[df[target_column].isnull()]
    df_not_missing = df[df[target_column].notnull()]

    # Prepare features (X) and target (y) for regression
    X_train = df_not_missing[[predictor_column]]
    y_train = df_not_missing[target_column]

    # Train the Linear Regression model
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Predict missing target_column values
    X_missing = df_missing[[predictor_column]]
    predicted_values = model.predict(X_missing)

    # Impute missing values
    df.loc[df[target_column].isnull(), target_column] = predicted_values

    return df


def impute_missing(df):
  df.columns = df.columns.str.replace(' ', '_')
#   df.set_index(['Customer_Id'], inplace=True)
  df['Emp_Title'] = df['Emp_Title'].fillna('unknown')
  df = impute_with_regression(df, target_column='Int_Rate', predictor_column='Grade')
  df['Emp_Length'] = df['Emp_Length'].fillna('unknown')
  df['Description'] = df['Description'].fillna('unknown')
  df['Annual_Inc_Joint'] = df['Annual_Inc_Joint'].fillna(df['Annual_Inc'])
  return df












# def clean_column_names(df):
#     df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
#     df.set_index('invoice_id', inplace=True)
#     return df

# def calculate_tax(price, quantity):
#     return (price * quantity) * 0.05

# def impute_missing(df):
#     # Impute missing branch
#     city_branch = df.groupby('city')['branch'].value_counts()
#     city_branch_dict = {city: branch for city, branch in city_branch.index}
#     df['branch'] = df['branch'].fillna(df['city'].map(city_branch_dict))

#     # Impute missing tax 5%
#     df['tax_5%'] = df['tax_5%'].fillna(df.apply(lambda x: calculate_tax(x['unit_price'], x['quantity']), axis=1))

#     return df

# def encoding(df):
#     global lookup
#     lookup = pd.DataFrame(columns=['Column', 'Old Value', 'New Value'])
#     # Changing date & time
#     df['datetime'] = df['date'].astype(str) + ' ' + df['time'].astype(str)
#     df['datetime'] = pd.to_datetime(df['datetime'])
#     df.drop(columns=['date', 'time'], inplace=True)
#     # Label Encoding
#     label_encoders = {}
#     columns_to_encode = ['branch', 'city', 'gender', 'product_line']

#     for column in columns_to_encode:
#         le = LabelEncoder()
#         df[column] = le.fit_transform(df[column])
#         label_encoders[column] = le
#         # Save the mapping
#         mapping_df = pd.DataFrame({
#             'Column': [column] * len(le.classes_),
#             'Old Value': le.classes_,
#             'New Value': range(len(le.classes_))
#         })
#         lookup = pd.concat([lookup, mapping_df], ignore_index=True)

#     # One Hot Encoding
#     df['is_member'] = df['customer_type'].apply(lambda x: 1 if x == 'Member' else 0)
#     df.drop(columns=['customer_type'], inplace=True)

#     # One Hot Encoding 0,1
#     df = pd.get_dummies(df, columns=['payment'], drop_first=True)
#     df.columns = df.columns.str.lower().str.replace(' ', '_')
#     df.replace({False: 0, True: 1}, inplace=True)

#     return df