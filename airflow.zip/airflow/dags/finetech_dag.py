from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

from _functions.cleaning import load_to_db, extract_clean,extract_states, combine_sources, encoding

# Define the DAG
default_args = {
    "owner": "data_engineering_team",
    "depends_on_past": False,
    'start_date': days_ago(2),
    "retries": 0,
}

with DAG(
    dag_id = 'finetech_dag',
    schedule_interval = '@once', # could be @daily, @hourly, etc or a cron expression '* * * * *'
    default_args = default_args,
    tags = ['pipeline', 'etl', 'sales'],
)as dag:
    # Define the tasks
    extract_clean_data = PythonOperator(
        task_id = 'extract_clean',
        python_callable = extract_clean,
        op_kwargs = {
            'filename': '/opt/airflow/data/fintech_data_18_28_12339.csv',
            'output_path': '/opt/airflow/data/fintech_clean.parquet'
        }
    )

    extract_states_data = PythonOperator(
        task_id = 'extract_states',
        python_callable = extract_states,
        op_kwargs = {
            'filename': '/opt/airflow/data/states.csv',
            'output_path': '/opt/airflow/data/fintech_states.parquet'
        }
    )
    combine_sources_data = PythonOperator(
        task_id = 'combine_sources',
        python_callable = combine_sources,
        op_kwargs = {
            'filename1': '/opt/airflow/data/fintech_clean.parquet',
            'filename2': '/opt/airflow/data/fintech_states.parquet',
            'output_path': '/opt/airflow/data/fintech_combined.parquet'
        }
    )
    encoding_data = PythonOperator(
        task_id = 'encoding_sources',
        python_callable = encoding,
        op_kwargs = {
            'filename': '/opt/airflow/data/fintech_combined.parquet',
            'output_path': '/opt/airflow/data/fintech_encoded.parquet'
        }
    )

    # transform_sales = PythonOperator(
    #     task_id = 'transform_sales',
    #     python_callable = transform_sales_data,
    #     op_kwargs = {
    #         'filename': '/opt/airflow/data/fintech_data_18_28_12339.csv',
    #         'output_path': '/opt/airflow/data/fintech_data_18_28_12339_clean.csv'
    #     }
    # )

    load_to_postgres = PythonOperator(
        task_id = 'load_to_postgres',
        python_callable = load_to_db,
        op_kwargs = {
            'filename': '/opt/airflow/data/fintech_encoded.parquet',
            'table_name': 'fintech_clean',
            'postgres_opt': {
                'user': 'root',
                'password': 'root',
                'host': 'pgdatabase',
                'port': 5432,
                'db': 'data_engineering'
            }
        }
    )

    # Define the task dependencies
    extract_clean_data >> combine_sources_data >> encoding_data >> load_to_postgres
    extract_states_data >> combine_sources_data >> encoding_data >> load_to_postgres